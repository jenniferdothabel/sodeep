#!/bin/bash
# DEEP ANAL Startup Script

echo "Starting DEEP ANAL - Steganography Analysis Platform"
echo "============================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install --upgrade pip
pip install -r local_requirements.txt

# Check system tools
echo "Checking system tools..."
command -v exiftool >/dev/null 2>&1 || { echo "Warning: exiftool not found. Install with: sudo apt install exiftool"; }
command -v binwalk >/dev/null 2>&1 || { echo "Warning: binwalk not found. Install with: sudo apt install binwalk"; }
command -v steghide >/dev/null 2>&1 || { echo "Warning: steghide not found. Install with: sudo apt install steghide"; }
command -v zsteg >/dev/null 2>&1 || { echo "Warning: zsteg not found. Install with: sudo gem install zsteg"; }

echo "Starting DEEP ANAL..."
echo "Access the application at: http://localhost:5001"
streamlit run main.py --server.port=5001 --server.address=0.0.0.0
