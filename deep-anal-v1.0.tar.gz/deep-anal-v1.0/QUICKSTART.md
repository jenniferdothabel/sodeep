# DEEP ANAL - Quick Start Guide

## Fastest Setup (Docker)
```bash
docker-compose up -d
open http://localhost
```

## Local Installation
```bash
# Linux/Mac
./start.sh

# Windows
start.bat

# Manual
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate   # Windows
pip install -r local_requirements.txt
streamlit run main.py --server.port=5001
```

## Access
- Main App: http://localhost:5001
- Upload images to analyze for hidden data
- View detection results and visualizations

## Test the System
```bash
python generate_test_images.py --clean --stego
# Upload the generated test images to verify detection accuracy
```

## Need Help?
- See INSTALL.md for detailed setup instructions
- Check README.md for full documentation
- View PRESENTATION.md for technical details
